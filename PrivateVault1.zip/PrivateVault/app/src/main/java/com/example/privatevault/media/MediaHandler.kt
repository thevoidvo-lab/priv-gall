package com.example.privatevault.media

import android.content.Context
import java.io.File

object MediaHandler {

    private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp")
    private val VIDEO_EXTENSIONS = setOf("mp4")

    fun vaultDir(context: Context): File {
        val dir = File(context.filesDir, "vault")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun tempDir(context: Context): File {
        val dir = File(context.cacheDir, "vault_temp")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun encryptedFileFor(context: Context, id: String): File {
        return File(vaultDir(context), id)
    }

    fun isSupportedExtension(ext: String): Boolean {
        val lower = ext.lowercase()
        return lower in IMAGE_EXTENSIONS || lower in VIDEO_EXTENSIONS
    }

    fun mimeTypeFor(ext: String): String {
        return if (ext.lowercase() in VIDEO_EXTENSIONS) "video" else "image"
    }

    fun extractExtension(fileName: String): String {
        val idx = fileName.lastIndexOf('.')
        return if (idx != -1 && idx < fileName.length - 1) fileName.substring(idx + 1) else ""
    }

    fun clearTempDir(context: Context) {
        try {
            tempDir(context).listFiles()?.forEach { it.delete() }
        } catch (e: Exception) {
            // gagal bersihin temp, gak fatal, biarin keganti/numpuk dikit
        }
    }
}
