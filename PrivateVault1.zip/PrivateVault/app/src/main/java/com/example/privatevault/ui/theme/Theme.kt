package com.example.privatevault.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = VaultPurple,
    secondary = VaultPurpleDark,
    background = VaultBackground,
    surface = VaultSurface,
    surfaceVariant = VaultSurfaceVariant,
    onPrimary = VaultTextPrimary,
    onBackground = VaultTextPrimary,
    onSurface = VaultTextPrimary,
    error = VaultError
)

private val LightColors = lightColorScheme(
    primary = VaultPurple,
    secondary = VaultPurpleDark,
    error = VaultError
)

@Composable
fun PrivateVaultTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // App ini default dark mode terus, sesuai spek, gak ngikutin system theme buat konsistensi vault
    val colorScheme = DarkColors

    MaterialTheme(
        colorScheme = colorScheme,
        typography = VaultTypography,
        content = content
    )
}
