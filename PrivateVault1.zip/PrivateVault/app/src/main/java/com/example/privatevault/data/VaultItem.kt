package com.example.privatevault.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey val id: String, // UUID, juga jadi nama file terenkripsi di filesDir/vault/
    val originalName: String,
    val mimeType: String, // "image" atau "video"
    val extension: String, // jpg, png, mp4, dst — buat tau cara render
    val dateAdded: Long = System.currentTimeMillis(),
    val sizeBytes: Long = 0L
)
