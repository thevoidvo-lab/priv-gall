package com.example.privatevault.data

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.privatevault.media.MediaHandler
import com.example.privatevault.media.ZipImporter
import com.example.privatevault.util.SessionKeyHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class ImportState {
    object Idle : ImportState()
    object Importing : ImportState()
    data class Done(val imported: Int, val skipped: Int) : ImportState()
    data class Error(val message: String) : ImportState()
}

class VaultViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = VaultDatabase.getInstance(application).vaultItemDao()

    val items: StateFlow<List<VaultItem>> = dao.getAll()
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    private val _importState = MutableStateFlow<ImportState>(ImportState.Idle)
    val importState: StateFlow<ImportState> = _importState

    fun importZip(uri: Uri) {
        val key = SessionKeyHolder.key
        if (key == null) {
            _importState.value = ImportState.Error("Vault terkunci")
            return
        }
        _importState.value = ImportState.Importing
        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    ZipImporter.importZip(getApplication(), uri, key)
                }
                if (result.items.isNotEmpty()) {
                    dao.insertAll(result.items)
                }
                _importState.value = ImportState.Done(result.importedCount, result.skippedCount)
            } catch (e: Exception) {
                _importState.value = ImportState.Error(e.message ?: "Import gagal")
            }
        }
    }

    fun resetImportState() {
        _importState.value = ImportState.Idle
    }

    fun deleteItem(item: VaultItem) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = MediaHandler.encryptedFileFor(getApplication(), item.id)
            if (file.exists()) file.delete()
            dao.delete(item)
        }
    }
}
