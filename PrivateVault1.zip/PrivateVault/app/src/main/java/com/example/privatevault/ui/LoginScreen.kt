package com.example.privatevault.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.privatevault.util.PasswordManager
import com.example.privatevault.util.SessionKeyHolder
import kotlinx.coroutines.delay

@Composable
fun LoginScreen(onLoginSuccess: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var password by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var lockoutRemaining by remember { mutableStateOf(PasswordManager.getLockoutRemainingMs(context)) }

    LaunchedEffect(lockoutRemaining > 0) {
        while (lockoutRemaining > 0) {
            delay(1000)
            lockoutRemaining = PasswordManager.getLockoutRemainingMs(context)
        }
    }

    val isLocked = lockoutRemaining > 0

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            Icon(
                imageVector = Icons.Default.LockOpen,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(64.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(text = "Private Vault", style = MaterialTheme.typography.headlineMedium)

            Spacer(modifier = Modifier.height(24.dp))

            if (isLocked) {
                Text(
                    text = "Terlalu banyak percobaan gagal.\nCoba lagi dalam ${(lockoutRemaining / 1000) + 1} detik",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; errorText = null },
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorText != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorText ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (PasswordManager.verifyPassword(context, password)) {
                            SessionKeyHolder.key = PasswordManager.deriveVaultKey(context, password)
                            onLoginSuccess()
                        } else {
                            val remaining = PasswordManager.getLockoutRemainingMs(context)
                            if (remaining > 0) {
                                lockoutRemaining = remaining
                            } else {
                                val fails = PasswordManager.getFailCount(context)
                                errorText = "Password salah (${fails}/${PasswordManager.MAX_ATTEMPTS})"
                            }
                            password = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Masuk")
                }
            }
        }
    }
}
