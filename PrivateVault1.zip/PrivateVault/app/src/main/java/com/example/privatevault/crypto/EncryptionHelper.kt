package com.example.privatevault.crypto

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object EncryptionHelper {
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_IV_LENGTH = 12
    private const val GCM_TAG_LENGTH_BITS = 128

    /**
     * Enkripsi dari InputStream langsung ke file tujuan.
     * Format file output: [12 byte IV][ciphertext + auth tag]
     * Streaming, jadi aman dipake buat video gede tanpa ngabisin RAM.
     */
    fun encryptStreamToFile(input: InputStream, outputFile: File, key: SecretKey) {
        val iv = ByteArray(GCM_IV_LENGTH)
        SecureRandom().nextBytes(iv)

        val cipher = Cipher.getInstance(TRANSFORMATION)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.ENCRYPT_MODE, key, spec)

        FileOutputStream(outputFile).use { fos ->
            fos.write(iv)
            CipherOutputStream(fos, cipher).use { cos ->
                input.use { it.copyTo(cos) }
            }
        }
    }

    /**
     * Decrypt dari file terenkripsi, balikin ByteArray hasil decrypt.
     * Dipake buat gambar (perlu full bytes buat ditampilkan via Coil dari memori)
     * dan thumbnail. Untuk video, pakai decryptToTempFile supaya ExoPlayer bisa stream.
     */
    fun decryptFileToBytes(encryptedFile: File, key: SecretKey): ByteArray {
        FileInputStream(encryptedFile).use { fis ->
            val iv = ByteArray(GCM_IV_LENGTH)
            val read = fis.read(iv)
            if (read != GCM_IV_LENGTH) throw IllegalStateException("File korup, IV gak lengkap")

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
            cipher.init(Cipher.DECRYPT_MODE, key, spec)

            CipherInputStream(fis, cipher).use { cis ->
                return cis.readBytes()
            }
        }
    }

    /**
     * Decrypt file ke temp file di cacheDir, dipake ExoPlayer buat play video
     * tanpa harus load seluruh video ke RAM. Temp file dihapus manual setelah selesai diputar.
     */
    fun decryptFileToTempFile(encryptedFile: File, key: SecretKey, tempFile: File) {
        FileInputStream(encryptedFile).use { fis ->
            val iv = ByteArray(GCM_IV_LENGTH)
            val read = fis.read(iv)
            if (read != GCM_IV_LENGTH) throw IllegalStateException("File korup, IV gak lengkap")

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
            cipher.init(Cipher.DECRYPT_MODE, key, spec)

            CipherInputStream(fis, cipher).use { cis ->
                FileOutputStream(tempFile).use { fos ->
                    cis.copyTo(fos)
                }
            }
        }
    }
}
