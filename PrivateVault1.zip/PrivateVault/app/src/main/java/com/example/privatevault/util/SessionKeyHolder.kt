package com.example.privatevault.util

import javax.crypto.SecretKey

/**
 * Nyimpen SecretKey hasil derive PBKDF2 di memori SELAMA app kebuka aja.
 * Gak pernah ditulis ke disk/prefs dalam bentuk apapun.
 * Dibersihin tiap app masuk background (onStop MainActivity) biar user wajib login ulang.
 */
object SessionKeyHolder {
    var key: SecretKey? = null

    fun clear() {
        key = null
    }

    fun isUnlocked(): Boolean = key != null
}
