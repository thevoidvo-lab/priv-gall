package com.example.privatevault.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.privatevault.crypto.KeyDerivation

object PasswordManager {
    private const val PREFS_NAME = "vault_secure_prefs"
    private const val KEY_HASH = "password_hash"
    private const val KEY_SALT = "password_salt"
    private const val KEY_FAIL_COUNT = "fail_count"
    private const val KEY_LOCKOUT_UNTIL = "lockout_until"

    const val MAX_ATTEMPTS = 5
    const val LOCKOUT_DURATION_MS = 30_000L

    private fun getPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        return EncryptedSharedPreferences.create(
            context,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun isPasswordSet(context: Context): Boolean {
        return getPrefs(context).contains(KEY_HASH)
    }

    fun setPassword(context: Context, password: String) {
        val salt = KeyDerivation.generateSalt()
        val hash = KeyDerivation.deriveHashForStorage(password.toCharArray(), salt)
        getPrefs(context).edit()
            .putString(KEY_HASH, hash)
            .putString(KEY_SALT, KeyDerivation.saltToString(salt))
            .putInt(KEY_FAIL_COUNT, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .apply()
    }

    fun verifyPassword(context: Context, password: String): Boolean {
        val prefs = getPrefs(context)
        val storedHash = prefs.getString(KEY_HASH, null) ?: return false
        val saltStr = prefs.getString(KEY_SALT, null) ?: return false
        val salt = KeyDerivation.saltFromString(saltStr)
        val candidateHash = KeyDerivation.deriveHashForStorage(password.toCharArray(), salt)

        val match = constantTimeEquals(candidateHash, storedHash)
        if (match) {
            prefs.edit().putInt(KEY_FAIL_COUNT, 0).putLong(KEY_LOCKOUT_UNTIL, 0L).apply()
        } else {
            registerFailedAttempt(context)
        }
        return match
    }

    /**
     * Dipanggil sesudah password cocok buat dapetin SecretKey AES
     * yang dipakai buat enkripsi/dekripsi file di vault.
     */
    fun deriveVaultKey(context: Context, password: String) =
        run {
            val prefs = getPrefs(context)
            val saltStr = prefs.getString(KEY_SALT, null) ?: throw IllegalStateException("Salt gak ada, password belum diset")
            val salt = KeyDerivation.saltFromString(saltStr)
            KeyDerivation.deriveKey(password.toCharArray(), salt)
        }

    private fun registerFailedAttempt(context: Context) {
        val prefs = getPrefs(context)
        val fails = prefs.getInt(KEY_FAIL_COUNT, 0) + 1
        val editor = prefs.edit().putInt(KEY_FAIL_COUNT, fails)
        if (fails >= MAX_ATTEMPTS) {
            editor.putLong(KEY_LOCKOUT_UNTIL, System.currentTimeMillis() + LOCKOUT_DURATION_MS)
            editor.putInt(KEY_FAIL_COUNT, 0)
        }
        editor.apply()
    }

    fun getLockoutRemainingMs(context: Context): Long {
        val until = getPrefs(context).getLong(KEY_LOCKOUT_UNTIL, 0L)
        val remaining = until - System.currentTimeMillis()
        return if (remaining > 0) remaining else 0L
    }

    fun getFailCount(context: Context): Int = getPrefs(context).getInt(KEY_FAIL_COUNT, 0)

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var result = 0
        for (i in a.indices) {
            result = result or (a[i].code xor b[i].code)
        }
        return result == 0
    }
}
