package com.example.privatevault.crypto

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object KeyDerivation {
    private const val ITERATIONS = 100_000
    private const val KEY_LENGTH_BITS = 256
    private const val SALT_LENGTH_BYTES = 16
    private const val ALGORITHM = "PBKDF2WithHmacSHA256"

    fun generateSalt(): ByteArray {
        val salt = ByteArray(SALT_LENGTH_BYTES)
        SecureRandom().nextBytes(salt)
        return salt
    }

    fun deriveKey(password: CharArray, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH_BITS)
        val factory = SecretKeyFactory.getInstance(ALGORITHM)
        val keyBytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(keyBytes, "AES")
    }

    fun deriveHashForStorage(password: CharArray, salt: ByteArray): String {
        val key = deriveKey(password, salt)
        return Base64.encodeToString(key.encoded, Base64.NO_WRAP)
    }

    fun saltToString(salt: ByteArray): String = Base64.encodeToString(salt, Base64.NO_WRAP)
    fun saltFromString(saltStr: String): ByteArray = Base64.decode(saltStr, Base64.NO_WRAP)
}
