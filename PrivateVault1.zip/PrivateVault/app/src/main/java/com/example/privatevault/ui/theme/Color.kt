package com.example.privatevault.ui.theme

import androidx.compose.ui.graphics.Color

val VaultPurple = Color(0xFF7C4DFF)
val VaultPurpleDark = Color(0xFF5E35B1)
val VaultBackground = Color(0xFF121212)
val VaultSurface = Color(0xFF1E1E1E)
val VaultSurfaceVariant = Color(0xFF2A2A2A)
val VaultTextPrimary = Color(0xFFFFFFFF)
val VaultTextSecondary = Color(0xFFB0B0B0)
val VaultError = Color(0xFFCF6679)
