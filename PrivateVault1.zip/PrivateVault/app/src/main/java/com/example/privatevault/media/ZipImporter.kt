package com.example.privatevault.media

import android.content.Context
import android.net.Uri
import com.example.privatevault.crypto.EncryptionHelper
import com.example.privatevault.data.VaultItem
import java.io.File
import java.util.UUID
import java.util.zip.ZipInputStream
import javax.crypto.SecretKey

data class ImportResult(
    val importedCount: Int,
    val skippedCount: Int,
    val items: List<VaultItem>
)

object ZipImporter {

    /**
     * Ekstrak zip dari Uri secara streaming (gak nulis file asli ke disk sama sekali),
     * tiap entry gambar/video langsung dienkripsi AES-256-GCM ke filesDir/vault/<uuid>.
     * File asli di dalam zip gak pernah disimpan dalam bentuk plain.
     */
    fun importZip(context: Context, zipUri: Uri, key: SecretKey): ImportResult {
        val items = mutableListOf<VaultItem>()
        var skipped = 0

        val resolver = context.contentResolver
        resolver.openInputStream(zipUri)?.use { rawInput ->
            ZipInputStream(rawInput).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val fileName = entry.name.substringAfterLast('/')
                        val ext = MediaHandler.extractExtension(fileName)

                        if (MediaHandler.isSupportedExtension(ext)) {
                            val id = UUID.randomUUID().toString()
                            val destFile = MediaHandler.encryptedFileFor(context, id)

                            try {
                                // NonClosingInputStream biar ZipInputStream gak ikut keclose
                                // oleh .use{} di dalam encryptStreamToFile
                                val entryStream = NonClosingInputStream(zis)
                                EncryptionHelper.encryptStreamToFile(entryStream, destFile, key)

                                items.add(
                                    VaultItem(
                                        id = id,
                                        originalName = fileName,
                                        mimeType = MediaHandler.mimeTypeFor(ext),
                                        extension = ext.lowercase(),
                                        dateAdded = System.currentTimeMillis(),
                                        sizeBytes = destFile.length()
                                    )
                                )
                            } catch (e: Exception) {
                                if (destFile.exists()) destFile.delete()
                                skipped++
                            }
                        } else {
                            skipped++
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }

        return ImportResult(items.size, skipped, items)
    }

    /**
     * Wrapper biar ZipInputStream gak ketutup pas dipake di dalam try-with-resources
     * function lain (encryptStreamToFile manggil input.use{} yang bakal nutup stream aslinya).
     */
    private class NonClosingInputStream(private val wrapped: java.io.InputStream) : java.io.InputStream() {
        override fun read(): Int = wrapped.read()
        override fun read(b: ByteArray, off: Int, len: Int): Int = wrapped.read(b, off, len)
        override fun available(): Int = wrapped.available()
        override fun close() {
            // sengaja gak nutup wrapped stream, biar ZipInputStream tetep bisa lanjut ke entry berikutnya
        }
    }
}
