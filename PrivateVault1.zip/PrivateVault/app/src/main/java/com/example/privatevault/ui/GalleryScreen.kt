@file:OptIn(ExperimentalFoundationApi::class)

package com.example.privatevault.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.privatevault.crypto.EncryptionHelper
import com.example.privatevault.data.ImportState
import com.example.privatevault.data.VaultItem
import com.example.privatevault.data.VaultViewModel
import com.example.privatevault.media.MediaHandler
import com.example.privatevault.util.SessionKeyHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun GalleryScreen(
    onItemClick: (String) -> Unit,
    viewModel: VaultViewModel = viewModel()
) {
    val items by viewModel.items.collectAsState()
    val importState by viewModel.importState.collectAsState()
    var itemPendingDelete by remember { mutableStateOf<VaultItem?>(null) }

    val pickZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importZip(uri)
    }

    LaunchedEffect(importState) {
        if (importState is ImportState.Done || importState is ImportState.Error) {
            kotlinx.coroutines.delay(2500)
            viewModel.resetImportState()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Private Vault") }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { pickZipLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed")) },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Import ZIP") }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {

            if (items.isEmpty()) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Vault masih kosong",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Tap \"Import ZIP\" buat mulai",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(4.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(items, key = { it.id }) { item ->
                        VaultThumbnail(
                            item = item,
                            onClick = { onItemClick(item.id) },
                            onLongClick = { itemPendingDelete = item }
                        )
                    }
                }
            }

            when (val state = importState) {
                is ImportState.Importing -> {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).fillMaxWidth(),
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Mengimpor & mengenkripsi...")
                        }
                    }
                }
                is ImportState.Done -> {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).fillMaxWidth(),
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "Berhasil import ${state.imported} file, ${state.skipped} dilewati",
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                is ImportState.Error -> {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).fillMaxWidth(),
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            text = "Gagal: ${state.message}",
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                else -> {}
            }
        }
    }

    itemPendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { itemPendingDelete = null },
            title = { Text("Hapus file?") },
            text = { Text("\"${item.originalName}\" bakal dihapus permanen dari vault.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteItem(item)
                    itemPendingDelete = null
                }) { Text("Hapus") }
            },
            dismissButton = {
                TextButton(onClick = { itemPendingDelete = null }) { Text("Batal") }
            }
        )
    }
}

@Composable
fun VaultThumbnail(item: VaultItem, onClick: () -> Unit, onLongClick: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(item.id) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(item.id) { mutableStateOf(false) }

    LaunchedEffect(item.id) {
        if (item.mimeType == "image") {
            withContext(Dispatchers.IO) {
                try {
                    val key = SessionKeyHolder.key ?: return@withContext
                    val file = MediaHandler.encryptedFileFor(context, item.id)
                    val bytes = EncryptionHelper.decryptFileToBytes(file, key)
                    val options = BitmapFactory.Options().apply { inSampleSize = 4 }
                    bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                    if (bitmap == null) failed = true
                } catch (e: Exception) {
                    failed = true
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .padding(2.dp)
            .aspectRatio(1f)
            .clip(MaterialTheme.shapes.small)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        contentAlignment = Alignment.Center
    ) {
        when {
            item.mimeType == "video" -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxSize()) {}
                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = "Video",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
            bitmap != null -> {
                Image(
                    bitmap = bitmap!!.asImageBitmap(),
                    contentDescription = item.originalName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            failed -> {
                Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxSize()) {}
            }
            else -> {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxSize()) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}
