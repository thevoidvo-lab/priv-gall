# Private Vault

Galeri foto/video pribadi terenkripsi penuh (AES-256-GCM), isolated dari sistem Android (gak masuk MediaStore, gak ada akses internet).

## Cara build

Upload semua isi folder ini ke repo GitHub → tab Actions → tunggu build selesai → download APK dari Artifacts.

## Cara pakai

1. Buka pertama kali → buat password (min 6 karakter)
2. Tap "Import ZIP" → pilih file .zip berisi foto/video dari file manager
3. Semua gambar (.jpg/.jpeg/.png/.webp) dan video (.mp4) di dalam zip otomatis diekstrak, dienkripsi, dan file plain-nya gak pernah disimpan ke disk
4. Tap thumbnail buat lihat fullscreen
5. Long-press thumbnail buat hapus
6. App keluar dari foreground (minimize/switch app) → otomatis logout, wajib masukin password lagi

## Soal keamanan — gimana ini dijamin "isolated"

- **Tidak ada permission INTERNET** di Manifest sama sekali — bukan cuma "gak dipanggil", tapi beneran gak ada jalur ke jaringan di level OS
- **Tidak pernah daftar ke MediaStore** — file terenkripsi cuma ada di `filesDir/vault/`, gak muncul di galeri bawaan HP atau app lain
- **FLAG_SECURE** aktif di seluruh app (bukan cuma galeri) — screenshot & preview recent-apps diblokir total
- **Password gak pernah disimpan dalam bentuk plain** — yang disimpan cuma hash hasil PBKDF2 (100rb iterasi) di EncryptedSharedPreferences
- **Key enkripsi cuma ada di RAM** selama app kebuka, dihapus otomatis begitu app masuk background (lewat `onStop`)
- Tiap file punya **IV unik sendiri** (12 byte, disimpan di awal file terenkripsi) — gak ada reuse IV antar file
- `allowBackup="false"` + `dataExtractionRules` — vault gak ikut kebackup ke Google/cloud atau pindah device transfer otomatis

## Penyesuaian dari spek

- Thumbnail video di grid pake ikon play generik (bukan frame asli video) — decode frame dari video terenkripsi butuh proses ekstra yang lumayan berat buat tiap item grid. Pas dibuka di viewer, video-nya full didecrypt & diputer normal lewat ExoPlayer.
- Thumbnail gambar di-downsample (`inSampleSize = 4`) biar grid tetep smooth scroll-nya, gambar full-res tetep kebuka pas masuk viewer.
- Argon2 gak dipakai (PBKDF2 aja) — Argon2 butuh library native (`argon2-jvm`) yang nambah kompleksitas build tanpa bedanya kerasa buat use-case app personal kayak gini; 100.000 iterasi PBKDF2-HMAC-SHA256 udah termasuk standar yang kuat.

Kalau ada error pas build atau nemu bug pas dipake, kirim detailnya.
