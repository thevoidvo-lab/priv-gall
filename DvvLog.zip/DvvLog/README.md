# DvvLog

Simple local Android utility for receiving console logs from other apps on the same device via HTTP.

## Features

- Lightweight HTTP server (NanoHTTPD) running in a Foreground Service on port **8080**
- Accepts `POST` with JSON body: `{"type": "LOG", "text": "your message"}`
- Timestamped logs in a clean Compose UI
- **Multiple themes**: Terminal, White & Black, Black & White, Pink & Blue
- **Copy all logs** to clipboard
- Picture-in-Picture (PiP) – shows only a small icon (no terminal text)
- Persistent notification while the server is running

## How to use

1. Open the project in Android Studio (Giraffe or newer recommended).
2. Let Gradle sync.
3. Run on a device/emulator (API 26+).
4. Tap **Start Server**.
5. From another app or `adb shell` / `curl`:

```bash
curl -X POST http://127.0.0.1:8080 \
  -H "Content-Type: application/json" \
  -d '{"type":"LOG","text":"Hello from curl"}'
```

## UI Controls

- **Start / Stop Server** – main button near the bottom
- **Copy icon** – copies all current logs to clipboard
- **PiP icon** – enters Picture-in-Picture (minimal icon-only view)
- **Theme dropdown** – switch between Terminal / White & Black / Black & White / Pink & Blue
- **Clear** – clears the log list

## Permissions

- `INTERNET`
- `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE`
- `POST_NOTIFICATIONS` (Android 13+)

## Build

```bash
./gradlew assembleDebug
```

APK will be at `app/build/outputs/apk/debug/`.

## GitHub Actions

A workflow is included under `.github/workflows/build.yml` that builds the debug APK on push/PR.
