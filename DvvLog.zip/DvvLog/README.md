# DvvLog

Simple local Android utility for receiving console logs from other apps on the same device via HTTP.

## Features

- Lightweight HTTP server (NanoHTTPD) running in a Foreground Service on port **8080**
- Accepts `POST` with JSON body: `{"type": "LOG", "text": "your message"}`
- Dark terminal-style UI with timestamped logs (Jetpack Compose)
- Picture-in-Picture (PiP) support
- Persistent notification while the server is running

## How to use

1. Open the project in Android Studio (Giraffe or newer recommended).
2. Let Gradle sync.
3. Run on a device/emulator (API 26+).
4. Tap **Start Server**.
5. From another app or `adb shell` / `curl`:

```bash
curl -X POST http://127.0.0.1:8080 \
  -H "Content-Type: application/json" \
  -d '{"type":"LOG","text":"Hello from curl"}'
```

## Permissions

- `INTERNET`
- `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE`
- `POST_NOTIFICATIONS` (Android 13+)

## Build

```bash
./gradlew assembleDebug
```

APK will be at `app/build/outputs/apk/debug/`.

## GitHub Actions

A workflow is included under `.github/workflows/build.yml` that builds the debug APK on push/PR.
