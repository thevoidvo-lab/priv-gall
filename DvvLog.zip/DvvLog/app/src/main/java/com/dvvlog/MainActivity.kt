package com.dvvlog

import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

enum class AppTheme(val label: String) {
    TERMINAL("Terminal"),
    WHITE_BLACK("White & Black"),
    BLACK_WHITE("Black & White"),
    PINK_BLUE("Pink & Blue")
}

data class ThemeColors(
    val background: Color,
    val surface: Color,
    val text: Color,
    val secondaryText: Color,
    val accent: Color,
    val buttonStart: Color,
    val buttonStop: Color
)

fun getThemeColors(theme: AppTheme): ThemeColors {
    return when (theme) {
        AppTheme.TERMINAL -> ThemeColors(
            background = Color(0xFF0D0D0D),
            surface = Color(0xFF1A1A1A),
            text = Color(0xFF00E676),
            secondaryText = Color(0xFF88AA88),
            accent = Color(0xFF00E676),
            buttonStart = Color(0xFF1B5E20),
            buttonStop = Color(0xFFB71C1C)
        )
        AppTheme.WHITE_BLACK -> ThemeColors(
            background = Color(0xFFFFFFFF),
            surface = Color(0xFFF5F5F5),
            text = Color(0xFF000000),
            secondaryText = Color(0xFF555555),
            accent = Color(0xFF000000),
            buttonStart = Color(0xFF212121),
            buttonStop = Color(0xFFB71C1C)
        )
        AppTheme.BLACK_WHITE -> ThemeColors(
            background = Color(0xFF000000),
            surface = Color(0xFF1A1A1A),
            text = Color(0xFFFFFFFF),
            secondaryText = Color(0xFFAAAAAA),
            accent = Color(0xFFFFFFFF),
            buttonStart = Color(0xFF424242),
            buttonStop = Color(0xFFB71C1C)
        )
        AppTheme.PINK_BLUE -> ThemeColors(
            background = Color(0xFF1A0A1A),
            surface = Color(0xFF2A1530),
            text = Color(0xFFFF80AB),
            secondaryText = Color(0xFF80D8FF),
            accent = Color(0xFFFF80AB),
            buttonStart = Color(0xFF880E4F),
            buttonStop = Color(0xFF0D47A1)
        )
    }
}

class MainActivity : ComponentActivity() {

    private var isServerRunning by mutableStateOf(false)
    private var isInPip by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }

        setContent {
            var currentTheme by remember { mutableStateOf(AppTheme.TERMINAL) }
            val colors = getThemeColors(currentTheme)

            Surface(
                modifier = Modifier.fillMaxSize(),
                color = colors.background
            ) {
                LogScreen(
                    isRunning = isServerRunning,
                    isInPip = isInPip,
                    colors = colors,
                    currentTheme = currentTheme,
                    onThemeChange = { currentTheme = it },
                    onToggle = { toggleServer() },
                    onEnterPip = { enterPipMode() }
                )
            }
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPip = isInPictureInPictureMode
    }

    private fun toggleServer() {
        val intent = Intent(this, LogServerService::class.java)
        if (isServerRunning) {
            intent.action = LogServerService.ACTION_STOP
            startService(intent)
            isServerRunning = false
        } else {
            intent.action = LogServerService.ACTION_START
            ContextCompat.startForegroundService(this, intent)
            isServerRunning = true
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(9, 16))
                .build()
            enterPictureInPictureMode(params)
        }
    }
}

@Composable
fun LogScreen(
    isRunning: Boolean,
    isInPip: Boolean,
    colors: ThemeColors,
    currentTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit,
    onToggle: () -> Unit,
    onEnterPip: () -> Unit
) {
    val logs by LogRepository.logs.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var themeExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            scope.launch {
                listState.animateScrollToItem(logs.size - 1)
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp)
            .padding(top = 8.dp, bottom = 12.dp)
    ) {
        // Status line (hide in PiP to save space)
        if (!isInPip) {
            Text(
                text = if (isRunning) "● Listening on http://127.0.0.1:8080" else "○ Server stopped",
                color = colors.secondaryText,
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 10.dp)
            )
        }

        // Log area – ALWAYS shown (including in PiP)
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(colors.surface, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            items(logs) { line ->
                Text(
                    text = line,
                    color = colors.text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = if (isInPip) 10.sp else 12.sp,
                    modifier = Modifier.padding(vertical = 1.dp)
                )
            }
        }

        // Controls – hide completely when in PiP
        if (!isInPip) {
            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onToggle,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRunning) colors.buttonStop else colors.buttonStart
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = if (isRunning) "Stop Server" else "Start Server",
                        color = Color.White
                    )
                }

                // Copy All
                IconButton(
                    onClick = {
                        val allText = logs.joinToString("\n")
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("DvvLog", allText))
                        Toast.makeText(context, "Copied ${logs.size} lines", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy all",
                        tint = colors.accent
                    )
                }

                // PiP
                IconButton(onClick = onEnterPip) {
                    Icon(
                        imageVector = Icons.Default.PictureInPictureAlt,
                        contentDescription = "Enter PiP",
                        tint = colors.accent
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Theme selector + Clear
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { themeExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Theme: ${currentTheme.label}", color = colors.text)
                    }
                    DropdownMenu(
                        expanded = themeExpanded,
                        onDismissRequest = { themeExpanded = false }
                    ) {
                        AppTheme.entries.forEach { theme ->
                            DropdownMenuItem(
                                text = { Text(theme.label) },
                                onClick = {
                                    onThemeChange(theme)
                                    themeExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedButton(onClick = { LogRepository.clear() }) {
                    Text("Clear", color = colors.text)
                }
            }
        }
    }
}
