package com.dvvlog

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object LogRepository {
    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs = _logs.asStateFlow()

    private val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    fun add(text: String) {
        val line = "[${sdf.format(Date())}] $text"
        _logs.value = _logs.value + line
    }

    fun clear() {
        _logs.value = emptyList()
    }
}
