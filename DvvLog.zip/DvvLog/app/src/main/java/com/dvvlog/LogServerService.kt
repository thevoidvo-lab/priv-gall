package com.dvvlog

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.IOException

class LogServerService : Service() {

    companion object {
        const val CHANNEL_ID = "dvvlog_server"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.dvvlog.START"
        const val ACTION_STOP = "com.dvvlog.STOP"
        const val PORT = 8080
    }

    private var server: LogHttpServer? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startServer()
            ACTION_STOP -> stopServer()
        }
        return START_STICKY
    }

    private fun startServer() {
        if (server != null) return

        createNotificationChannel()
        val notification = buildNotification("Listening on :$PORT")
        startForeground(NOTIFICATION_ID, notification)

        server = LogHttpServer(PORT).apply {
            try {
                start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                LogRepository.add("Server started on port $PORT")
            } catch (e: IOException) {
                LogRepository.add("Failed to start server: ${e.message}")
                stopSelf()
            }
        }
    }

    private fun stopServer() {
        server?.stop()
        server = null
        LogRepository.add("Server stopped")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopServer()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DvvLog Server",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Local log receiver"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(content: String): Notification {
        val stopIntent = Intent(this, LogServerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DvvLog")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    private inner class LogHttpServer(port: Int) : NanoHTTPD(port) {
        override fun serve(session: IHTTPSession): Response {
            if (session.method != Method.POST) {
                return newFixedLengthResponse(
                    Response.Status.METHOD_NOT_ALLOWED,
                    MIME_PLAINTEXT,
                    "POST only"
                )
            }

            return try {
                val files = HashMap<String, String>()
                session.parseBody(files)
                val body = files["postData"] ?: ""
                val json = JSONObject(body)

                if (json.optString("type") == "LOG") {
                    val text = json.optString("text", "")
                    if (text.isNotBlank()) {
                        LogRepository.add(text)
                    }
                }

                newFixedLengthResponse(
                    Response.Status.OK,
                    "application/json",
                    """{"ok":true}"""
                )
            } catch (e: Exception) {
                newFixedLengthResponse(
                    Response.Status.BAD_REQUEST,
                    MIME_PLAINTEXT,
                    e.message ?: "Bad request"
                )
            }
        }
    }
}
