package com.example.privatevault

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.privatevault.ui.GalleryScreen
import com.example.privatevault.ui.LoginScreen
import com.example.privatevault.ui.SetupScreen
import com.example.privatevault.ui.ViewerScreen
import com.example.privatevault.ui.theme.PrivateVaultTheme
import com.example.privatevault.util.PasswordManager
import com.example.privatevault.util.SessionKeyHolder

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // FLAG_SECURE: blokir screenshot & preview di recent apps buat SELURUH app,
        // bukan cuma galeri, biar isi vault gak pernah kebocor lewat screenshot/recents.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        setContent {
            PrivateVaultTheme {
                VaultApp()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // App masuk background -> kunci vault, key dihapus dari memori.
        // User wajib masukin password lagi pas balik, biar vault gak nganggur kebuka.
        //
        // KECUALI kalau onStop ini dipicu karena system File Picker lagi kebuka
        // (misal pas Import ZIP) — itu bukan user beneran ninggalin app, cuma
        // Activity sementara ketutup sama picker. Flag isPickingFile nandain itu.
        if (!SessionKeyHolder.isPickingFile) {
            SessionKeyHolder.clear()
        }
    }
}

@Composable
fun VaultApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val navController: NavHostController = rememberNavController()

    val startDestination = remember {
        if (!PasswordManager.isPasswordSet(context)) "setup" else "login"
    }

    NavHost(navController = navController, startDestination = startDestination) {

        composable("setup") {
            SetupScreen(onSetupComplete = {
                navController.navigate("gallery") {
                    popUpTo("setup") { inclusive = true }
                }
            })
        }

        composable("login") {
            LoginScreen(onLoginSuccess = {
                navController.navigate("gallery") {
                    popUpTo("login") { inclusive = true }
                }
            })
        }

        composable("gallery") {
            GalleryScreen(onItemClick = { itemId ->
                navController.navigate("viewer/$itemId")
            })
        }

        composable("viewer/{itemId}") { backStackEntry ->
            val itemId = backStackEntry.arguments?.getString("itemId") ?: return@composable
            ViewerScreen(itemId = itemId, onBack = { navController.popBackStack() })
        }
    }
}
