package com.example.privatevault.util

import javax.crypto.SecretKey

/**
 * Nyimpen SecretKey hasil derive PBKDF2 di memori SELAMA app kebuka aja.
 * Gak pernah ditulis ke disk/prefs dalam bentuk apapun.
 * Dibersihin tiap app masuk background (onStop MainActivity) biar user wajib login ulang.
 */
object SessionKeyHolder {
    var key: SecretKey? = null

    /**
     * True selama system File Picker/Document Picker lagi kebuka (misal pas Import ZIP).
     * Picker itu teknisnya bikin MainActivity masuk onStop(), sama persis kayak
     * user beneran ninggalin app — jadi tanpa flag ini, auto-lock bakal salah nganggep
     * itu minimize dan ngehapus key di tengah proses pilih file.
     */
    var isPickingFile = false

    fun clear() {
        key = null
    }

    fun isUnlocked(): Boolean = key != null
}
