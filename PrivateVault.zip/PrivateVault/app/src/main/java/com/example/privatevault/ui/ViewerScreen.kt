package com.example.privatevault.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.privatevault.crypto.EncryptionHelper
import com.example.privatevault.data.VaultItem
import com.example.privatevault.data.VaultViewModel
import com.example.privatevault.media.MediaHandler
import com.example.privatevault.util.SessionKeyHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ViewerScreen(
    itemId: String,
    onBack: () -> Unit,
    viewModel: VaultViewModel = viewModel()
) {
    val context = LocalContext.current
    val items by viewModel.items.collectAsState()
    val item = items.find { it.id == itemId }

    Box(modifier = Modifier.fillMaxSize()) {
        if (item == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (item.mimeType == "image") {
            ImageViewer(item)
        } else {
            VideoViewer(item)
        }

        IconButton(
            onClick = onBack,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .background(
                    color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.4f),
                    shape = androidx.compose.foundation.shape.CircleShape
                )
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Kembali",
                tint = androidx.compose.ui.graphics.Color.White
            )
        }
    }
}

@Composable
private fun ImageViewer(item: VaultItem) {
    val context = LocalContext.current
    var bitmap by remember(item.id) { mutableStateOf<Bitmap?>(null) }
    var error by remember(item.id) { mutableStateOf(false) }

    LaunchedEffect(item.id) {
        withContext(Dispatchers.IO) {
            try {
                val key = SessionKeyHolder.key ?: return@withContext
                val file = MediaHandler.encryptedFileFor(context, item.id)
                val bytes = EncryptionHelper.decryptFileToBytes(file, key)
                bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bitmap == null) error = true
            } catch (e: Exception) {
                error = true
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when {
            bitmap != null -> {
                Image(
                    bitmap = bitmap!!.asImageBitmap(),
                    contentDescription = item.originalName,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            error -> Text("Gagal memuat gambar", color = MaterialTheme.colorScheme.error)
            else -> CircularProgressIndicator()
        }
    }
}

@Composable
private fun VideoViewer(item: VaultItem) {
    val context = LocalContext.current
    var tempFile by remember(item.id) { mutableStateOf<File?>(null) }
    var error by remember(item.id) { mutableStateOf(false) }

    LaunchedEffect(item.id) {
        withContext(Dispatchers.IO) {
            try {
                val key = SessionKeyHolder.key ?: return@withContext
                val encryptedFile = MediaHandler.encryptedFileFor(context, item.id)
                val dest = File(MediaHandler.tempDir(context), "${item.id}.${item.extension}")
                EncryptionHelper.decryptFileToTempFile(encryptedFile, key, dest)
                tempFile = dest
            } catch (e: Exception) {
                error = true
            }
        }
    }

    DisposableEffect(item.id) {
        onDispose {
            // bersihin plaintext video dari cache begitu viewer ditutup
            tempFile?.let { if (it.exists()) it.delete() }
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when {
            tempFile != null -> {
                VideoPlayerView(uri = Uri.fromFile(tempFile))
            }
            error -> Text("Gagal memuat video", color = MaterialTheme.colorScheme.error)
            else -> CircularProgressIndicator()
        }
    }
}

@Composable
private fun VideoPlayerView(uri: Uri) {
    val context = LocalContext.current
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    AndroidView(
        factory = {
            PlayerView(it).apply {
                player = exoPlayer
                useController = true
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}
